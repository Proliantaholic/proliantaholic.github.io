#########################################
#  Slipstream patches and drivers into  #
#  vSphere 5.x                          #
#                                       #
#  http://proliantaholic.blogspot.com   #
#########################################
#
#
#
#
#
#
#
#
#

Add-PSSnapin VMware.VimAutomation.Core
Add-PSSnapin VMware.ImageBuilder

# Check ESXi 5 offline bundle file existence
If (!(Test-Path .\bundle\*.zip)) {
Write-Host "Error: ESXi 5 offline bundle file not found." -ForegroundColor red
exit
}

# Check patch file existence
If (!(Test-Path .\patch\*.zip)) {
Write-Host "Error: Patch file not found." -ForegroundColor red
exit
}

# Choose what to do
Do {
Write-Host "What would you like to generate?"
Write-Host "  (1) Slipstream patches only (-standard)"
Write-Host "  (2) Slipstream patches and drivers (-async)"
Write-Host "  (3) Both kinds"
$choice = Read-Host "Enter your choice"
Write-Host
} While (!(($choice -eq "1") -or ($choice -eq "2") -or ($choice -eq "3")))

# Check driver offline bundle file existence
If ((!(Test-Path .\vib20)) -and (($choice -eq "2") -or ($choice -eq "3"))) {
Write-Host
Write-Host "Error: Driver offline bundle file not found, generate w/patches only instead..." -ForegroundColor red
$choice = "1"
}

# Get the offline bundle file name
$bundle = (Get-Item .\bundle\*.zip | Select-Object -First 1 Name)

# Add patches to software depot
Write-Host
Write-Host "********************************************************************************" -BackgroundColor yellow
Write-Host "Add patches to software depot..." -ForegroundColor yellow
Get-Item .\patch\*.zip | ? {Add-ESXSoftwareDepot (".\patch\" + $_.Name), (".\bundle\" + $bundle.Name)} | Select-Object Name

# Show all image profiles for checkup
Get-EsxImageProfile | Sort-Object ModifiedTime | Out-GridView

# Get the most updated "standard" image profile for exoprt
$Img = (Get-EsxImageProfile | ? {($_.Name -like "*standard") -and ($_.Name -notlike "*s-standard")} | Sort-Object ModifiedTime | Select-Object -Last 1 Name)

# Generate ISO file (w/patches only)
If (($choice -eq "1") -or ($choice -eq "3")) {
Write-Host
Write-Host "********************************************************************************" -BackgroundColor yellow
Write-Host "Generating ISO file (w/patches only):" ($Img.Name + ".iso") -ForegroundColor green
Export-EsxImageProfile -ImageProfile $Img.Name -ExportToISO -filepath ($Img.Name + ".iso") -Force
Write-Host "Done."
}

###############################
#  Add driver section starts  #
###############################
If (($choice -eq "2") -or ($choice -eq "3"))
{

# Add driver offline bundle to software depot
Write-Host
Write-Host "********************************************************************************" -BackgroundColor yellow
Write-Host "Add driver offline bundle to software depot..." -ForegroundColor yellow
Get-Item .\driver\*.zip | ? {Add-ESXSoftwareDepot (".\driver\" + $_.Name), (".\bundle\" + $bundle.Name)} | Select-Object Name
Get-EsxSoftwarePackage | Sort-Object Vendor | Out-GridView

# Clone to new image profile
Write-Host
Write-Host "********************************************************************************" -BackgroundColor yellow
Write-Host "Clone to new image profile..." -ForegroundColor yellow
New-EsxImageProfile -CloneProfile $Img.Name -name ($ImgIsoName = $Img.Name.replace("standard","async")) | Select-Object Name

# Add driver software package to the newly created image progile
Write-Host
Write-Host "********************************************************************************" -BackgroundColor yellow
Write-Host "Add driver software package to the newly created image progile..." -ForegroundColor yellow
Get-Item .\vib20\* | ? {Add-EsxSoftwarePackage -ImageProfile $ImgIsoName -SoftwarePackage $_.Name} | Select-Object Name

# Generate ISO file (w/patches and drivers)
Write-Host
Write-Host "********************************************************************************" -BackgroundColor yellow
Write-Host "Generating ISO file (w/patches and drivers):" ($ImgIsoName + ".iso") -ForegroundColor green
Export-EsxImageProfile -ImageProfile $ImgIsoName -ExportToISO -filepath ($ImgIsoName + ".iso") -Force
Write-Host "Done."
}
#############################
#  Add driver section ends  #
#############################

# Delete temp driver files
If (Test-Path .\vib20) {
Remove-Item .\vib20 -Recurse -Force
}